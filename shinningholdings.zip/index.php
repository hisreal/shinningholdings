<?php require_once("header.php"); ?>
<?php require_once("page_loader.php"); ?>
<?php require_once("nav-bar.php");?>
<?php require_once("slider.php"); ?>
<?php require_once("counter.php"); ?>
<?php require_once("footer.php"); ?>